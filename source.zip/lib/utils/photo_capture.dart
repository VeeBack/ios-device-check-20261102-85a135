import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:native_exif/native_exif.dart';

/// iOS's in-app camera supplies a capture time but does not geotag its images.
/// Track actual device locations while the camera is open, then add the fix
/// nearest the original capture time. Never use this for library imports.
Future<XFile?> captureGeotaggedPhoto(Future<XFile?> Function() capture) async {
  var permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
  }
  if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
    throw const FormatException('Camera capture requires location permission');
  }

  const settings = LocationSettings(accuracy: LocationAccuracy.best);
  final positions = [
    await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        timeLimit: Duration(seconds: 20),
      ),
    ),
  ];
  final subscription = Geolocator.getPositionStream(locationSettings: settings).listen(
    positions.add,
    // A stream failure must not supply a fabricated or stale capture location.
    onError: (Object _) {},
  );
  XFile? image;
  try {
    image = await capture();
  } finally {
    await subscription.cancel();
  }
  if (image == null) return null;

  final exif = await Exif.fromPath(image.path);
  try {
    if (await exif.getLatLong() != null) return image;
    final capturedAt = await exif.getOriginalDate();
    if (capturedAt == null) throw const FormatException('Missing capture time');
    final position = positions.reduce(
      (a, b) => a.timestamp.difference(capturedAt).abs() <= b.timestamp.difference(capturedAt).abs()
          ? a
          : b,
    );
    if (position.timestamp.difference(capturedAt).abs() > const Duration(seconds: 30)) {
      throw const FormatException('No location near the capture time');
    }
    // Preserve the camera's capture time and other metadata; only add GPS.
    await exif.writeAttributes({
      'GPSLatitude': position.latitude.abs().toString(),
      'GPSLatitudeRef': position.latitude < 0 ? 'S' : 'N',
      'GPSLongitude': position.longitude.abs().toString(),
      'GPSLongitudeRef': position.longitude < 0 ? 'W' : 'E',
    });
  } finally {
    await exif.close();
  }
  return image;
}
