import 'dart:io';

import 'package:exif/exif.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';

import '/utils/photo_metadata_validator.dart';

/// iOS's in-app camera supplies a capture time but does not geotag its images.
/// Track actual device locations while the camera is open, then retain the fix
/// nearest the original capture time for upload without changing the file.
/// Never use this for library imports.
Future<({XFile image, ({double latitude, double longitude})? location})?> capturePhotoWithLocation(
  Future<XFile?> Function() capture,
) async {
  var permission = await Geolocator.checkPermission();
  if (permission == LocationPermission.denied) {
    permission = await Geolocator.requestPermission();
  }
  if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
    throw const FormatException('Camera capture requires location permission');
  }

  const settings = LocationSettings(accuracy: LocationAccuracy.best);
  final positions = [
    await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        timeLimit: Duration(seconds: 20),
      ),
    ),
  ];
  final subscription = Geolocator.getPositionStream(locationSettings: settings).listen(
    positions.add,
    // A stream failure must not supply a fabricated or stale capture location.
    onError: (Object _) {},
  );
  XFile? image;
  try {
    image = await capture();
  } finally {
    await subscription.cancel();
  }
  if (image == null) return null;

  final exif = await readExifFromFile(File(image.path));
  final tags = exif.map((key, value) => MapEntry(key, value.printable));
  final capturedAt = photoCaptureTime(tags);
  try {
    validatePhotoMetadata(tags);
    return (image: image, location: null);
  } on FormatException {
    // Only missing/invalid GPS is supplemented; the original time is required.
  }
  final position = positions.reduce(
    (a, b) => a.timestamp.difference(capturedAt).abs() <= b.timestamp.difference(capturedAt).abs()
        ? a
        : b,
  );
  if (position.timestamp.difference(capturedAt).abs() > const Duration(seconds: 30)) {
    throw const FormatException('No location near the capture time');
  }
  return (image: image, location: (latitude: position.latitude, longitude: position.longitude));
}
