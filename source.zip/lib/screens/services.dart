import 'package:flutter/material.dart' hide View;
import 'package:flutter_mvvm_architecture/base.dart';

import '/commons/panoramax_config.dart';
import '/l10n/app_localizations.g.dart';
import '/view_models/services_view_model.dart';
import '/widgets/custom_list_tile.dart';

class ServicesScreen extends View<ServicesViewModel> {
  const ServicesScreen({super.key}) : super(create: ServicesViewModel.new);

  @override
  Widget build(BuildContext context, viewModel) {
    final appLocale = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(appLocale.servicesTitle),
      ),
      body: Scrollbar(
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).padding.bottom),
          child: Column(
            children: [
              CustomListTile(
                leadingIcon: Icons.panorama,
                title: 'Panoramax',
                subtitle: viewModel.panoramaxInstance.host,
                trailingIcon: Icons.open_in_new,
                onTap: viewModel.openPanoramaxWebsite,
              ),
              CustomListTile(
                leadingIcon: Icons.settings,
                title: appLocale.servicesPanoramaxInstance,
                subtitle: viewModel.panoramaxInstance.toString(),
                onTap: () => showDialog<void>(
                  context: context,
                  builder: (context) => _PanoramaxInstanceDialog(
                    instance: viewModel.panoramaxInstance.toString(),
                    onConfirm: viewModel.changePanoramaxInstance,
                  ),
                ),
              ),
              if (viewModel.panoramaxUserIsLoggedIn) ...[
                CustomListTile(
                  leadingIcon: Icons.person,
                  title: viewModel.panoramaxUserName!,
                  onTap: viewModel.openPanoramaxUserProfile,
                ),
                CustomListTile(
                  leadingIcon: Icons.logout,
                  title: appLocale.logout,
                  onTap: viewModel.logoutPanoramax,
                ),
              ] else
                CustomListTile(
                  leadingIcon: Icons.login,
                  title: appLocale.login,
                  onTap: viewModel.loginPanoramax,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PanoramaxInstanceDialog extends StatefulWidget {
  final String instance;
  final Future<bool> Function(String value) onConfirm;

  const _PanoramaxInstanceDialog({
    required this.instance,
    required this.onConfirm,
  });

  @override
  State<_PanoramaxInstanceDialog> createState() => _PanoramaxInstanceDialogState();
}

class _PanoramaxInstanceDialogState extends State<_PanoramaxInstanceDialog> {
  late final _controller = TextEditingController(text: widget.instance);

  bool _busy = false;

  bool _failed = false;

  Future<void> _confirm() async {
    setState(() {
      _busy = true;
      _failed = false;
    });
    final success = await widget.onConfirm(_controller.text);
    if (!mounted) return;
    if (success) {
      Navigator.pop(context);
    } else {
      setState(() {
        _busy = false;
        _failed = true;
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appLocale = AppLocalizations.of(context)!;

    return AlertDialog(
      title: Text(appLocale.servicesPanoramaxInstance),
      content: TextField(
        controller: _controller,
        enabled: !_busy,
        keyboardType: TextInputType.url,
        decoration: InputDecoration(
          hintText: kPanoramaxUrl,
          errorText: _failed ? appLocale.servicesInstanceError : null,
        ),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.pop(context),
          child: Text(appLocale.cancel),
        ),
        TextButton(
          onPressed: _busy ? null : _confirm,
          child: Text(appLocale.confirm),
        ),
      ],
    );
  }
}
