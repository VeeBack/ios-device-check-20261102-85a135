import 'package:flutter/material.dart' hide View;
import 'package:flutter_mvvm_architecture/base.dart';

import '/commons/panoramax_config.dart';
import '/commons/themes.dart';
import '/l10n/app_localizations.g.dart';
import '/view_models/services_view_model.dart';

class ServicesScreen extends View<ServicesViewModel> {
  const ServicesScreen({super.key}) : super(create: ServicesViewModel.new);

  static const _buttonStyle = ButtonStyle(
    padding: WidgetStatePropertyAll(EdgeInsets.symmetric(horizontal: Default.padding * 2)),
  );

  @override
  Widget build(BuildContext context, viewModel) {
    final appLocale = AppLocalizations.of(context)!;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(appLocale.servicesTitle),
      ),
      body: Scrollbar(
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          padding: EdgeInsets.fromLTRB(
            Default.padding,
            Default.padding,
            Default.padding,
            Default.padding + MediaQuery.of(context).padding.bottom,
          ),
          child: Card.outlined(
            margin: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(Default.borderRadius),
              side: BorderSide(color: theme.colorScheme.outline),
            ),
            child: Padding(
              padding: const EdgeInsets.all(Default.padding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Panoramax',
                          style: theme.textTheme.titleLarge,
                        ),
                      ),
                      IconButton(
                        tooltip: appLocale.servicesPanoramaxInstance,
                        icon: const Icon(Icons.settings),
                        onPressed: () => showDialog<void>(
                          context: context,
                          builder: (context) => _PanoramaxInstanceDialog(
                            instance: viewModel.panoramaxInstance.toString(),
                            onConfirm: viewModel.changePanoramaxInstance,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Semantics(
                    link: true,
                    child: InkWell(
                      onTap: viewModel.openPanoramaxWebsite,
                      child: Text(
                        viewModel.panoramaxInstance.host,
                        style: TextStyle(
                          color: theme.colorScheme.primary,
                          decoration: TextDecoration.underline,
                          decorationColor: theme.colorScheme.primary,
                        ),
                      ),
                    ),
                  ),
                  Text(
                    viewModel.panoramaxUserIsLoggedIn
                        ? appLocale.servicesPanoramaxUser(viewModel.panoramaxUserName!)
                        : appLocale.servicesPanoramaxDescription,
                  ),
                  const SizedBox(height: Default.padding),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Wrap(
                      spacing: Default.padding,
                      runSpacing: Default.padding,
                      children: [
                        if (viewModel.panoramaxUserIsLoggedIn) ...[
                          OutlinedButton(
                            style: _buttonStyle,
                            onPressed: viewModel.openPanoramaxUserProfile,
                            child: Text(appLocale.servicesPanoramaxProfile),
                          ),
                          OutlinedButton(
                            style: _buttonStyle,
                            onPressed: viewModel.logoutPanoramax,
                            child: Text(appLocale.logout),
                          ),
                        ] else
                          OutlinedButton(
                            style: _buttonStyle,
                            onPressed: viewModel.loginPanoramax,
                            child: Text(appLocale.login),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _PanoramaxInstanceDialog extends StatefulWidget {
  final String instance;
  final Future<bool> Function(String value) onConfirm;

  const _PanoramaxInstanceDialog({
    required this.instance,
    required this.onConfirm,
  });

  @override
  State<_PanoramaxInstanceDialog> createState() => _PanoramaxInstanceDialogState();
}

class _PanoramaxInstanceDialogState extends State<_PanoramaxInstanceDialog> {
  late final _controller = TextEditingController(text: widget.instance);

  bool _busy = false;

  bool _failed = false;

  Future<void> _confirm() async {
    setState(() {
      _busy = true;
      _failed = false;
    });
    final success = await widget.onConfirm(_controller.text);
    if (!mounted) return;
    if (success) {
      Navigator.pop(context);
    } else {
      setState(() {
        _busy = false;
        _failed = true;
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appLocale = AppLocalizations.of(context)!;

    return AlertDialog(
      title: Text(appLocale.servicesPanoramaxInstance),
      content: TextField(
        controller: _controller,
        enabled: !_busy,
        keyboardType: TextInputType.url,
        decoration: InputDecoration(
          labelText: appLocale.servicesInstanceUrl,
          hintText: kPanoramaxUrl,
          enabledBorder: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(Default.borderRadius)),
            borderSide: BorderSide(color: Theme.of(context).colorScheme.outline),
          ),
          errorText: _failed ? appLocale.servicesInstanceError : null,
        ),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.pop(context),
          child: Text(appLocale.cancel),
        ),
        TextButton(
          onPressed: _busy ? null : _confirm,
          child: Text(appLocale.confirm),
        ),
      ],
    );
  }
}
