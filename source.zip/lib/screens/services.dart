import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '/api/panoramax_connection.dart';
import '/commons/panoramax_config.dart';
import '/l10n/app_localizations.g.dart';
import '/widgets/custom_list_tile.dart';
import '/widgets/panoramax_binding.dart';

class ServicesScreen extends StatelessWidget {
  const ServicesScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(AppLocalizations.of(context)!.servicesTitle)),
    body: PanoramaxBinding(
      builder: (context, connection) {
        final l = AppLocalizations.of(context)!;
        return ListView(
          padding: EdgeInsets.only(bottom: MediaQuery.paddingOf(context).bottom),
          children: [
            CustomListTile(
              leadingIcon: Icons.photo_camera_outlined,
              title: 'Panoramax',
              subtitle: connection.instance.name,
            ),
            CustomListTile(
              leadingIcon: Icons.language,
              title: connection.instance.url.toString(),
              onTap: () => launchUrl(connection.instance.url, mode: LaunchMode.externalApplication),
            ),
            CustomListTile(
              leadingIcon: Icons.settings,
              title: l.photoInstanceSettings,
              onTap: connection.locked ? null : () => _edit(context, connection),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (connection.isLoggedIn) ...[
                    Text(
                      connection.authenticatedUser!.name,
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    OutlinedButton(
                      onPressed: connection.locked ? null : connection.logout,
                      child: Text(l.photoSignOut),
                    ),
                  ] else
                    PanoramaxSignIn(connection),
                  PanoramaxPublication(connection),
                ],
              ),
            ),
          ],
        );
      },
    ),
  );
  Future<void> _edit(BuildContext context, PanoramaxConnection connection) async {
    final controller = TextEditingController(text: connection.instance.url.toString());
    var busy = false;
    String? error;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) {
          final l = AppLocalizations.of(context)!;
          return PopScope(
            canPop: !busy,
            child: AlertDialog(
              title: Text(l.photoInstanceSettings),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(l.photoInstanceExplanation),
                    const SizedBox(height: 16),
                    TextField(
                      controller: controller,
                      enabled: !busy,
                      keyboardType: TextInputType.url,
                      decoration: InputDecoration(labelText: l.photoInstanceUrl, errorText: error),
                    ),
                    if (busy) const LinearProgressIndicator(),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: busy ? null : () => controller.text = kPanoramaxUrl,
                  child: Text(l.photoResetInstance),
                ),
                TextButton(
                  onPressed: busy ? null : () => Navigator.pop(context),
                  child: Text(l.cancel),
                ),
                FilledButton(
                  onPressed: busy
                      ? null
                      : () async {
                          setState(() {
                            busy = true;
                            error = null;
                          });
                          try {
                            await connection.changeInstance(controller.text);
                            if (context.mounted) Navigator.pop(context);
                          } catch (_) {
                            if (context.mounted) {
                              setState(() {
                                busy = false;
                                error = l.photoInstanceError;
                              });
                            }
                          }
                        },
                  child: Text(l.photoSave),
                ),
              ],
            ),
          );
        },
      ),
    );
    controller.dispose();
  }
}
