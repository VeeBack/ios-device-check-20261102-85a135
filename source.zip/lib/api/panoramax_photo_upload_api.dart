import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';

import '/api/panoramax_authentication_api.dart';
import '/api/panoramax_instance.dart';
import '/models/element_variants/element_identifier.dart';
import '/models/panoramax_photo.dart';
import '/models/panoramax_upload_attempt.dart';

class PanoramaxPhotoUploadAPI {
  final Dio _client;
  final Duration pollTimeout;
  final Future<void> Function(Duration) delay;
  PanoramaxPhotoUploadAPI({
    required PanoramaxUploadContext context,
    Dio? client,
    this.pollTimeout = const Duration(minutes: 5),
    Future<void> Function(Duration)? delay,
  }) : _client =
           client ??
           panoramaxClient(
             context.instance,
             authorization: context.authentication.getAuthorizationHeader(),
           ),
       delay = delay ?? Future<void>.delayed;
  Future<List<Map>> files(String id) async {
    final data = (await _client.get<Map<String, dynamic>>('upload_sets/$id/files')).data!;
    return (data['files'] as List).cast<Map>();
  }

  static void verifyFiles(
    List<Map> files,
    Set<String> expected, {
    required bool ready,
    bool subset = false,
  }) {
    if (files.any(
      (f) => f['rejected'] != null && (!subset || expected.contains(f['picture_id'])),
    )) {
      throw const PanoramaxPhotoUploadException();
    }
    if (ready && !expected.every((id) => files.any((f) => f['picture_id'] == id))) {
      throw const PanoramaxPhotoUploadException();
    }
  }

  Future<void> upload({
    required List<PanoramaxPhoto> photos,
    required ElementIdentifier target,
    required String label,
    required PanoramaxUploadAttempt attempt,
    void Function(PhotoUploadStage)? onStage,
  }) async {
    final expected = photos.map((photo) => photo.id).toSet();
    final subset = expected.length != attempt.expectedIds.length;
    try {
      onStage?.call(PhotoUploadStage.uploading);
      final semantics = [
        {'key': 'osm_id', 'value': target.osmReference},
      ];
      if (attempt.uploadSetId == null) {
        final response = await _client.post<Map<String, dynamic>>(
          'upload_sets',
          data: {
            'title': 'OpenStop: $label (${target.osmReference})',
            'estimated_nb_files': photos.length,
            'no_split': true,
            'no_deduplication': true,
            'visibility': 'anyone',
            'semantics': semantics,
          },
        );
        attempt.uploadSetId = response.data!['id'] as String;
      }
      final id = attempt.uploadSetId!;
      final existing = await files(id);
      verifyFiles(existing, expected, ready: false, subset: subset);
      for (final photo in photos) {
        if (existing.any((f) => f['picture_id'] == photo.id)) continue;
        if (attempt.stage != PhotoUploadStage.uploading) {
          throw const PanoramaxPhotoUploadException();
        }
        try {
          final response = await _client.post<Map<String, dynamic>>(
            'upload_sets/$id/files',
            data: FormData.fromMap({
              'file': await MultipartFile.fromFile(photo.path, filename: '${photo.id}.jpg'),
              'picture_id': photo.id,
              'isBlurred': false,
              'override_latitude': photo.captureLocation.latitude,
              'override_longitude': photo.captureLocation.longitude,
              'semantics': MultipartFile.fromString(
                jsonEncode(semantics),
                contentType: DioMediaType('application', 'json'),
              ),
            }),
          );
          if (response.data?['rejected'] != null) throw const PanoramaxPhotoUploadException();
        } on DioException catch (e) {
          if (e.response?.statusCode != 409) rethrow;
          // Only the recorded upload set may own a retry's UUID.
          final owned = await files(id);
          verifyFiles(owned, expected, ready: false, subset: subset);
          if (!owned.any((f) => f['picture_id'] == photo.id)) {
            throw const PanoramaxPhotoUploadException(isDuplicate: true);
          }
        }
      }
      if (attempt.stage == PhotoUploadStage.uploading) {
        final set = (await _client.get<Map<String, dynamic>>('upload_sets/$id')).data!;
        if (set['account_id'] != attempt.context.accountId) {
          throw const PanoramaxPhotoUploadException();
        }
        // Edited selections may leave fewer files than the original estimate.
        // Complete only our recorded set, after all selected uploads were sent.
        if (set['completed'] == false) {
          await _client.post<void>('upload_sets/$id/complete');
        }
      }
      attempt.stage = PhotoUploadStage.processing;
      onStage?.call(PhotoUploadStage.processing);
      await waitForProcessing(attempt, selectedIds: expected);
      attempt.stage = PhotoUploadStage.saving;
      onStage?.call(PhotoUploadStage.saving);
    } on PanoramaxPhotoUploadException {
      // Definitive preparation failures only. Never delete a processed set after an OSM failure.
      if (attempt.stage == PhotoUploadStage.uploading && attempt.uploadSetId != null) {
        try {
          if (await abandonIncomplete(attempt)) attempt.uploadSetId = null;
        } catch (_) {
          /* Preserve the original error. */
        }
      }
      rethrow;
    } on DioException catch (e) {
      if ([401, 403].contains(e.response?.statusCode)) {
        throw const PanoramaxAuthenticationException();
      }
      rethrow;
    }
  }

  Future<void> waitForProcessing(PanoramaxUploadAttempt attempt, {Set<String>? selectedIds}) async {
    final expected = selectedIds ?? attempt.expectedIds;
    final subset = expected.length != attempt.expectedIds.length;
    final timer = Stopwatch()..start();
    var seconds = 1;
    for (;;) {
      final id = attempt.uploadSetId!;
      final data = (await _client.get<Map<String, dynamic>>('upload_sets/$id')).data!;
      if (data['account_id'] != attempt.context.accountId) {
        throw const PanoramaxPhotoUploadException();
      }
      final status = data['items_status'] as Map?;
      if (!subset &&
          ((status?['broken'] as int? ?? 0) > 0 || (status?['rejected'] as int? ?? 0) > 0)) {
        throw const PanoramaxPhotoUploadException();
      }
      final received = await files(id);
      verifyFiles(received, expected, ready: data['ready'] == true, subset: subset);
      if (data['ready'] == true ||
          (subset && expected.every((id) => received.any((f) => f['picture_id'] == id)))) {
        // Verify published items, including after a prior OSM failure.
        // Excluded rejected files may prevent set-wide readiness indefinitely.
        var allPublished = true;
        for (final photoId in expected) {
          final response = await _client.get<Map<String, dynamic>>(
            'search',
            queryParameters: {'ids': photoId},
          );
          if (!(response.data!['features'] as List).cast<Map<String, dynamic>>().any(
            (f) {
              final properties = f['properties'] as Map<String, dynamic>?;
              return f['id'] == photoId &&
                  (!subset ||
                      (properties?['geovisio:status'] == 'ready' &&
                          properties?['geovisio:visibility'] == 'anyone'));
            },
          )) {
            allPublished = false;
          }
        }
        if (allPublished) return;
        if (data['ready'] == true) throw const PanoramaxPhotoUploadException();
      }
      if (timer.elapsed >= pollTimeout) throw const PanoramaxProcessingTimeout();
      await delay(Duration(seconds: seconds));
      seconds = (seconds * 2).clamp(1, 15);
    }
  }

  Future<bool> abandonIncomplete(PanoramaxUploadAttempt attempt) async {
    final id = attempt.uploadSetId;
    if (id == null || attempt.stage != PhotoUploadStage.uploading) return false;
    final data = (await _client.get<Map<String, dynamic>>('upload_sets/$id')).data!;
    if (data['account_id'] == attempt.context.accountId &&
        data['completed'] == false &&
        data['ready'] != true) {
      await _client.delete<void>('upload_sets/$id');
      return true;
    }
    return false;
  }

  void dispose() => _client.close();
}

class PanoramaxPhotoUploadException implements Exception {
  final bool isDuplicate;
  const PanoramaxPhotoUploadException({this.isDuplicate = false});
}

class PanoramaxProcessingTimeout implements Exception {
  const PanoramaxProcessingTimeout();
}
