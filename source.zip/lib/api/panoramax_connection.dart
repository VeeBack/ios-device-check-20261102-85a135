import 'package:flutter/widgets.dart';
import '/api/panoramax_authentication_api.dart';
import '/api/panoramax_instance.dart';
import '/api/preferences_service.dart';
import '/api/user_account_service.dart';
import '/commons/panoramax_config.dart';

class PanoramaxConnection extends ChangeNotifier with WidgetsBindingObserver {
  final PreferencesService preferences;
  final UserAccountService<String> account;
  String? error;
  bool changing = false;
  PanoramaxAuthenticationAPI get api => account.api as PanoramaxAuthenticationAPI;
  PanoramaxInstance get instance => api.instance;
  PanoramaxConnection(this.preferences, this.account) {
    WidgetsBinding.instance.addObserver(this);
  }
  Future<void> loadMetadata() async {
    final url = instance.url;
    try {
      final metadata = await PanoramaxInstance.discover(url.toString());
      if (url == instance.url) {
        api.instance = metadata;
        notifyListeners();
      }
    } catch (_) {
      /* Keep the saved destination usable offline. */
    }
  }

  Future<void> changeInstance(String value) async {
    if (account.locked || changing) return;
    changing = true;
    notifyListeners();
    try {
      final metadata = await PanoramaxInstance.discover(value);
      await preferences.savePanoramaxInstance(metadata.url.toString());
      // Local sign-out only: credentials stay bound to the old instance.
      await account.clearLocalUser();
      api.instance = metadata;
      error = null;
      await account.refresh();
    } finally {
      changing = false;
      notifyListeners();
    }
  }

  Future<void> reset() => changeInstance(kPanoramaxUrl);
  Future<void> signIn() async {
    error = null;
    notifyListeners();
    try {
      await account.login();
    } on PanoramaxBrowserException {
      error = 'browser';
    } catch (_) {
      error = 'network';
    }
    notifyListeners();
  }

  Future<void> check() async {
    try {
      await account.completeLogin(api.checkLogin);
      error = api.pending ? 'waiting' : null;
    } catch (_) {
      error = 'network';
    }
    notifyListeners();
  }

  void cancel() {
    account.cancelLogin();
    error = null;
    notifyListeners();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && api.pending) check();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }
}
