import 'package:flutter/widgets.dart';
import 'package:mobx/mobx.dart';
import 'package:osm_api/osm_api.dart';

import '/api/authentication/authentication_api.dart';
import '/api/authentication/panoramax_authentication_api.dart';
import '/api/panoramax_instance.dart';
import '/api/preferences_service.dart';
import '/api/user_account_service.dart';
import '/commons/panoramax_config.dart';

/// The Panoramax account also owns instance selection and browser resumption.
class PanoramaxConnection extends UserAccountService<String> with WidgetsBindingObserver {
  final PreferencesService preferences;
  final Observable<PanoramaxInstance> _instance;
  final _error = Observable<String?>(null);
  final _changing = Observable(false);
  final _uploads = Observable(0);

  PanoramaxConnection(this.preferences, PanoramaxInstance instance)
    : _instance = Observable(instance),
      super(PanoramaxAuthenticationAPI(instance)) {
    WidgetsBinding.instance.addObserver(this);
  }

  PanoramaxInstance get instance => _instance.value;
  String? get error => _error.value;
  bool get changing => _changing.value;
  bool get locked => _uploads.value > 0;
  void lock() => runInAction(() => _uploads.value++);
  void unlock() => runInAction(() => _uploads.value--);

  Future<void> loadMetadata() async {
    final url = instance.url;
    try {
      final metadata = await PanoramaxInstance.discover(url.toString());
      if (url == instance.url && !changing) {
        updateApiConfiguration(PanoramaxAuthenticationAPI(metadata));
        runInAction(() => _instance.value = metadata);
      }
    } catch (_) {
      // Keep the saved destination usable offline.
    }
  }

  Future<void> changeInstance(String value) async {
    if (locked || changing) return;
    runInAction(() => _changing.value = true);
    try {
      final metadata = await PanoramaxInstance.discover(value);
      await clearLocalUser();
      await preferences.savePanoramaxInstance(metadata.url.toString());
      runInAction(() {
        _instance.value = metadata;
        _error.value = null;
      });
      updateApiConfiguration(PanoramaxAuthenticationAPI(metadata));
      await refresh();
    } finally {
      runInAction(() => _changing.value = false);
    }
  }

  Future<void> reset() => changeInstance(kPanoramaxUrl);

  @override
  Future<void> openLogin(AuthenticationAPI<String> api, OAuth2 authentication) =>
      (api as PanoramaxAuthenticationAPI).openLogin(authentication);

  Future<void> signIn() async {
    if (changing) return;
    runInAction(() => _error.value = null);
    try {
      await login();
      runInAction(() => _error.value = pending ? 'waiting' : null);
    } on PanoramaxBrowserException {
      runInAction(() => _error.value = 'browser');
    } catch (_) {
      runInAction(() => _error.value = 'network');
    }
  }

  Future<void> check() => signIn();

  void cancel() {
    cancelLogin();
    runInAction(() => _error.value = null);
  }

  @override
  Future<void> logout() async {
    if (locked || changing) return;
    await super.logout();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && pending) check();
  }

  void dispose() {
    cancelLogin();
    WidgetsBinding.instance.removeObserver(this);
  }
}
