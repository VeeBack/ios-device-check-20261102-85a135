import '/models/authenticated_user.dart';

abstract interface class AuthenticationAPI<I> {
  Future<AuthenticatedUser<I>?> restore();
  Future<AuthenticatedUser<I>?> login();
  Future<void> logout();
  void cancelLogin();
}
