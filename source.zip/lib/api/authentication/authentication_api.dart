import 'package:osm_api/osm_api.dart';
import '/models/authenticated_user.dart';

abstract interface class AuthenticationAPI<I> {
  Future<OAuth2?> restore();
  Future<OAuth2> login();
  Future<AuthenticatedUser<I>> user(OAuth2 authentication);
  Future<void> save(OAuth2 authentication);
  Future<void> logout();
}

/// A pregenerated credential has not yet been authorized in the browser.
class AuthenticationPendingException implements Exception {
  const AuthenticationPendingException();
}
