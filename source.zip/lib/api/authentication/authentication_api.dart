import 'package:osm_api/osm_api.dart';

import '/models/authenticated_user.dart';

/// Common interface for the services a user can log in to.
/// The type parameter is the type of the user ID used by the service.

abstract class AuthenticationAPI<I> {
  Future<OAuth2> login();

  Future<OAuth2?> restore();

  Future<void> logout();

  Future<AuthenticatedUser<I>> user(OAuth2 authentication);
}
