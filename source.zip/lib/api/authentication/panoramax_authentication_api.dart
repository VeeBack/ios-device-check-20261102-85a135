import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:osm_api/osm_api.dart';
import 'package:url_launcher/url_launcher.dart';

import '/api/authentication/authentication_api.dart';
import '/api/panoramax_instance.dart';
import '/commons/osm_config.dart';
import '/models/authenticated_user.dart';

class PanoramaxAuthenticationAPI implements AuthenticationAPI<String> {
  static const _storage = FlutterSecureStorage();
  final PanoramaxInstance instance;
  String get _key => 'panoramax.session.${instance.url}';

  const PanoramaxAuthenticationAPI(this.instance);

  @override
  Future<OAuth2?> restore() async {
    await _storage.delete(key: 'panoramaxToken');
    final value = await _storage.read(key: _key);
    if (value == null) return null;
    final session = jsonDecode(value) as Map;
    return _PanoramaxCredential(session['token'] as String, session['id'] as String);
  }

  @override
  Future<OAuth2> login() async {
    final data = (await _request(
      'auth/tokens/generate',
      method: 'POST',
      query: {'description': 'OpenStop'},
    )).data!;
    var claim = Uri.parse(
      (data['links'] as List).cast<Map<String, dynamic>>().firstWhere(
            (link) => link['rel'] == 'claim',
          )['href']
          as String,
    );
    if (claim.origin != instance.url.origin ||
        !claim.path.startsWith('${instance.url.path}/api/auth/tokens/')) {
      throw const PanoramaxAuthenticationException();
    }
    if (instance.supportsReturn) {
      claim = claim.replace(
        queryParameters: {
          ...claim.queryParameters,
          'next_url': kOAuth2RedirectUri,
        },
      );
    }
    return _PanoramaxCredential(data['jwt_token'] as String, data['id'] as String, claim);
  }

  Future<void> openLogin(OAuth2 authentication) async {
    final claim = (authentication as _PanoramaxCredential).claim!;
    if (!await launchUrl(claim, mode: LaunchMode.externalApplication)) {
      throw const PanoramaxBrowserException();
    }
  }

  @override
  Future<AuthenticatedUser<String>> user(OAuth2 authentication) async {
    try {
      final data = (await _request('users/me', authentication: authentication)).data!;
      final id = data['id'] as String;
      return AuthenticatedUser<String>(
        authentication: authentication,
        id: id,
        name: data['name'] as String? ?? id,
        profileUrl: instance.url.resolve('${instance.url.path}/?user=$id'),
      );
    } on DioException catch (error) {
      if ([401, 403].contains(error.response?.statusCode)) {
        throw const AuthenticationPendingException();
      }
      rethrow;
    }
  }

  @override
  Future<void> save(OAuth2 authentication) {
    final credential = authentication as _PanoramaxCredential;
    return _storage.write(
      key: _key,
      value: jsonEncode({'token': credential.accessToken, 'id': credential.id}),
    );
  }

  @override
  Future<void> logout() async {
    final value = await _storage.read(key: _key);
    await _storage.delete(key: _key);
    if (value == null) return;
    final session = jsonDecode(value) as Map;
    try {
      await _request(
        'users/me/tokens/${session['id']}',
        method: 'DELETE',
        authentication: OAuth2(accessToken: session['token'] as String),
      );
    } on DioException {
      // Local logout remains effective when offline.
    }
  }

  Future<Response<Map<String, dynamic>>> _request(
    String path, {
    String method = 'GET',
    OAuth2? authentication,
    Map<String, String>? query,
  }) async {
    final client = panoramaxClient(
      instance.url,
      authorization: authentication?.getAuthorizationHeader(),
    );
    try {
      return await client.request<Map<String, dynamic>>(
        path,
        queryParameters: query,
        options: Options(method: method),
      );
    } finally {
      client.close();
    }
  }
}

/// Carries the server's token ID so logout can revoke this credential.
class _PanoramaxCredential extends OAuth2 {
  final String id;
  final Uri? claim;
  const _PanoramaxCredential(String token, this.id, [this.claim]) : super(accessToken: token);
}

class PanoramaxAuthenticationException implements Exception {
  const PanoramaxAuthenticationException();
}

class PanoramaxBrowserException implements Exception {
  const PanoramaxBrowserException();
}
