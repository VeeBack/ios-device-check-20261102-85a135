import 'package:dio/dio.dart';
import '/commons/app_config.dart';

Uri normalizePanoramaxUrl(String value) {
  final uri = Uri.parse(value.trim());
  if (uri.scheme != 'https' ||
      uri.host.isEmpty ||
      uri.userInfo.isNotEmpty ||
      uri.hasQuery ||
      uri.hasFragment) {
    throw const FormatException('A secure instance URL is required');
  }
  return uri.replace(path: uri.path.replaceFirst(RegExp(r'/+$'), ''));
}

Dio panoramaxClient(Uri instance, {String? authorization}) => Dio(
  BaseOptions(
    baseUrl: '$instance/api/',
    followRedirects: false,
    connectTimeout: const Duration(seconds: 20),
    receiveTimeout: const Duration(seconds: 60),
    sendTimeout: const Duration(minutes: 1),
    headers: {
      'User-Agent': kAppUserAgent,
      'Authorization': ?authorization,
    },
  ),
);

class PanoramaxInstance {
  final Uri url;
  final String name;
  final Uri? license;
  final Uri? terms;
  final bool supportsReturn;
  const PanoramaxInstance(
    this.url, {
    required this.name,
    this.license,
    this.terms,
    this.supportsReturn = false,
  });
  static Future<PanoramaxInstance> discover(String value) async {
    final url = normalizePanoramaxUrl(value);
    final client = panoramaxClient(url);
    try {
      final root = (await client.get<Map<String, dynamic>>('')).data!;
      final spec = (await client.get<Map<String, dynamic>>('docs/specs.json')).data!;
      final paths = spec['paths'] as Map<String, dynamic>;
      for (final path in [
        '/api/auth/tokens/generate',
        '/api/users/me',
        '/api/upload_sets',
        '/api/upload_sets/{upload_set_id}',
        '/api/auth/tokens/{token_id}/claim',
        '/api/search',
        '/api/upload_sets/{upload_set_id}/files',
      ]) {
        if (!paths.containsKey(path)) throw const FormatException('Unsupported Panoramax API');
      }
      Uri? link(String rel) {
        for (final entry in (root['links'] as List? ?? []).cast<Map<String, dynamic>>()) {
          if (entry['rel'] == rel) {
            final uri = url.resolve(entry['href'] as String);
            if (uri.scheme == 'https') return uri;
          }
        }
        return null;
      }

      final claimPath = paths['/api/auth/tokens/{token_id}/claim'] as Map<String, dynamic>?;
      final claim = claimPath?['get'] as Map<String, dynamic>?;
      final supports = (claim?['parameters'] as List? ?? []).cast<Map<String, dynamic>>().any(
        (p) => p['name'] == 'next_url',
      );
      return PanoramaxInstance(
        url,
        name: root['title'] as String? ?? url.host,
        license: link('license'),
        terms: link('terms-of-service'),
        supportsReturn: supports,
      );
    } finally {
      client.close();
    }
  }
}
