import '/api/panoramax_photo_upload_api.dart';
import '/models/element_variants/element_identifier.dart';
import '/models/panoramax_photo.dart';
import '/models/panoramax_upload_attempt.dart';

/// Keeps ownership of every upload set across edits to a questionnaire's photos.
class PanoramaxPhotoUploadJob {
  final PanoramaxUploadContext context;
  final _attempts = <PanoramaxUploadAttempt>[];
  PanoramaxPhotoUploadJob(this.context);

  Future<void> upload({
    required PanoramaxUploadContext context,
    required List<PanoramaxPhoto> photos,
    required ElementIdentifier target,
    required String label,
  }) async {
    // A different session is not an expired credential. Never move a retry to it.
    if (this.context.instance != context.instance || this.context.accountId != context.accountId) {
      throw const PanoramaxPhotoUploadException();
    }
    final added = photos
        .where((photo) => !_attempts.any((a) => a.expectedIds.contains(photo.id)))
        .toList();
    if (added.isNotEmpty) {
      _attempts.add(PanoramaxUploadAttempt(context, added.map((photo) => photo.id)));
    }
    final api = PanoramaxPhotoUploadAPI(context: context);
    try {
      for (final attempt in _attempts.toList()) {
        final selected = photos.where((photo) => attempt.expectedIds.contains(photo.id)).toList();
        if (selected.isEmpty) continue;
        try {
          await api.upload(
            photos: selected,
            target: target,
            label: label,
            attempt: attempt,
          );
        } on PanoramaxPhotoUploadException {
          if (attempt.uploadSetId == null) _attempts.remove(attempt);
          rethrow;
        }
      }
    } finally {
      api.dispose();
    }
  }

  Future<void> abandonIncomplete() async {
    final api = PanoramaxPhotoUploadAPI(context: context);
    try {
      for (final attempt in _attempts) {
        try {
          await api.abandonIncomplete(attempt);
        } catch (_) {
          // Discard still removes local files; published sets are never deleted.
        }
      }
    } finally {
      api.dispose();
    }
  }
}
