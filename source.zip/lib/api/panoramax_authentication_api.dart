import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter_web_auth_2/flutter_web_auth_2.dart';
import 'package:osm_api/osm_api.dart';
import 'package:url_launcher/url_launcher.dart';
import '/api/authentication/authentication_api.dart';
import '/api/panoramax_instance.dart';
import '/commons/osm_config.dart';
import '/models/authenticated_user.dart';

class PanoramaxAuthenticationAPI implements AuthenticationAPI<String> {
  final Dio Function(Uri, {String? authorization}) clientFactory;
  final Future<void> Function(Uri)? browser;
  final FlutterSecureStorage storage;
  PanoramaxInstance instance;
  int _generation = 0;
  ({String token, String id})? _pending;
  bool _checking = false;
  String get _key => 'panoramax.session.${instance.url}';
  bool get pending => _pending != null;
  PanoramaxAuthenticationAPI(
    this.instance, {
    this.storage = const FlutterSecureStorage(),
    this.clientFactory = panoramaxClient,
    this.browser,
  });

  @override
  Future<AuthenticatedUser<String>?> restore() async {
    await storage.delete(key: 'panoramaxToken');
    final generation = _generation;
    final value = await storage.read(key: _key);
    if (value == null || generation != _generation) return null;
    final session = jsonDecode(value) as Map;
    try {
      return await _user(session['token'] as String);
    } on DioException catch (e) {
      if ([401, 403].contains(e.response?.statusCode)) {
        if (generation == _generation) await storage.delete(key: _key);
        return null;
      }
      rethrow;
    }
  }

  @override
  Future<AuthenticatedUser<String>?> login() async {
    if (pending) return checkLogin();
    final generation = ++_generation;
    final client = clientFactory(instance.url);
    try {
      final data = (await client.post<Map<String, dynamic>>(
        'auth/tokens/generate',
        queryParameters: {'description': 'OpenStop'},
      )).data!;
      if (generation != _generation) return null;
      final token = data['jwt_token'] as String;
      final id = data['id'] as String;
      var claim = Uri.parse(
        (data['links'] as List).cast<Map<String, dynamic>>().firstWhere(
              (l) => l['rel'] == 'claim',
            )['href']
            as String,
      );
      if (claim.origin != instance.url.origin ||
          !claim.path.startsWith('${instance.url.path}/api/auth/tokens/')) {
        throw const PanoramaxAuthenticationException();
      }
      _pending = (token: token, id: id);
      if (browser != null) {
        await browser!(claim);
      } else if (instance.supportsReturn) {
        final redirectUri = Uri.parse(kOAuth2RedirectUri);
        claim = claim.replace(
          queryParameters: {
            ...claim.queryParameters,
            'next_url': kOAuth2RedirectUri,
          },
        );
        try {
          await FlutterWebAuth2.authenticate(
            url: claim.toString(),
            callbackUrlScheme: redirectUri.scheme,
            options: FlutterWebAuth2Options(
              httpsHost: redirectUri.scheme == 'https' ? redirectUri.host : null,
              httpsPath: redirectUri.scheme == 'https' ? redirectUri.path : null,
            ),
          );
        } on PlatformException catch (e) {
          if (generation == _generation && e.code == 'CANCELED') {
            cancelLogin();
          } else if (generation == _generation) {
            throw const PanoramaxBrowserException();
          }
        }
      } else if (!await launchUrl(claim, mode: LaunchMode.externalApplication)) {
        cancelLogin();
        throw const PanoramaxBrowserException();
      }
      if (generation != _generation) return null;
      return await checkLogin();
    } finally {
      client.close();
    }
  }

  Future<AuthenticatedUser<String>?> checkLogin() async {
    final session = _pending;
    if (session == null || _checking) return null;
    _checking = true;
    final generation = _generation;
    final key = _key;
    try {
      final user = await _user(session.token);
      if (generation != _generation) return null;
      await storage.write(key: key, value: jsonEncode({'token': session.token, 'id': session.id}));
      if (generation != _generation) {
        await storage.delete(key: key);
        return null;
      }
      _pending = null;
      return user;
    } on DioException catch (e) {
      if ([401, 403].contains(e.response?.statusCode)) return null;
      rethrow;
    } finally {
      _checking = false;
    }
  }

  Future<AuthenticatedUser<String>> _user(String token) async {
    final client = clientFactory(instance.url, authorization: 'Bearer $token');
    try {
      final data = (await client.get<Map<String, dynamic>>('users/me')).data!;
      final id = data['id'] as String;
      return AuthenticatedUser<String>(
        authentication: OAuth2(accessToken: token),
        id: id,
        name: data['name'] as String? ?? id,
        profileUrl: instance.url.resolve('${instance.url.path}/?user=$id'),
      );
    } finally {
      client.close();
    }
  }

  @override
  void cancelLogin() {
    ++_generation;
    _pending = null;
  }

  @override
  Future<void> logout() async {
    cancelLogin();
    final key = _key;
    final value = await storage.read(key: key);
    await storage.delete(key: key);
    if (value == null) return;
    final session = jsonDecode(value) as Map;
    final client = clientFactory(instance.url, authorization: 'Bearer ${session['token']}');
    try {
      await client.delete<void>('users/me/tokens/${session['id']}');
    } on DioException {
      /* Local logout remains effective when offline. */
    } finally {
      client.close();
    }
  }
}

class PanoramaxAuthenticationException implements Exception {
  const PanoramaxAuthenticationException();
}

class PanoramaxBrowserException implements Exception {
  const PanoramaxBrowserException();
}
