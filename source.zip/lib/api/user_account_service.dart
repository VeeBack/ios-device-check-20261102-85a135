import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_mvvm_architecture/base.dart';
import 'package:mobx/mobx.dart';
import 'package:url_launcher/url_launcher.dart';
import '/api/authentication/authentication_api.dart';
import '/models/authenticated_user.dart';

class UserAccountService<I> extends Service {
  final AuthenticationAPI<I> api;
  final _user = Observable<AuthenticatedUser<I>?>(null);
  final _busy = Observable(false);
  final _locks = Observable(0);
  int _generation = 0;
  late final Future<void> initialized;
  UserAccountService(this.api) {
    initialized = _restore();
  }
  AuthenticatedUser<I>? get authenticatedUser => _user.value;
  bool get isLoggedIn => authenticatedUser != null;
  bool get isLoggedOut => !isLoggedIn;
  bool get busy => _busy.value;
  bool get locked => _locks.value > 0;
  void lock() => runInAction(() => _locks.value++);
  void unlock() => runInAction(() => _locks.value--);
  Future<void> _restore() async {
    final generation = _generation;
    try {
      final user = await api.restore();
      if (generation == _generation) runInAction(() => _user.value = user);
    } catch (error) {
      debugPrint('Account restoration unavailable: ${error.runtimeType}');
    }
  }

  Future<void> completeLogin(Future<AuthenticatedUser<I>?> Function() check) async {
    final generation = _generation;
    final user = await check();
    if (generation == _generation && user != null) runInAction(() => _user.value = user);
  }

  Future<void> clearLocalUser() async {
    cancelLogin();
    runInAction(() => _user.value = null);
  }

  Future<void> refresh() => _restore();
  Future<void> login() async {
    await initialized;
    if (busy || isLoggedIn) return;
    final generation = ++_generation;
    runInAction(() => _busy.value = true);
    try {
      final user = await api.login();
      if (generation == _generation && user != null) runInAction(() => _user.value = user);
    } on PlatformException catch (error) {
      if (error.code != 'CANCELED') rethrow;
    } finally {
      if (generation == _generation) runInAction(() => _busy.value = false);
    }
  }

  void cancelLogin() {
    ++_generation;
    api.cancelLogin();
    runInAction(() => _busy.value = false);
  }

  Future<void> logout() async {
    if (locked) return;
    cancelLogin();
    await initialized;
    try {
      await api.logout();
    } catch (error) {
      debugPrint('Remote logout unavailable: ${error.runtimeType}');
    } finally {
      runInAction(() => _user.value = null);
    }
  }

  Future<bool> openUserProfile() async {
    final url = authenticatedUser?.profileUrl;
    return url != null && await launchUrl(url, mode: LaunchMode.externalApplication);
  }
}
