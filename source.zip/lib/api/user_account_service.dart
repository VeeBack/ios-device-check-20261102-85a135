import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_mvvm_architecture/base.dart';
import 'package:mobx/mobx.dart';
import 'package:osm_api/osm_api.dart';

import '/api/authentication/authentication_api.dart';
import '/models/authenticated_user.dart';

/// The ID type keeps OSM integer IDs and Panoramax UUIDs distinct.
class UserAccountService<I> extends Service {
  AuthenticationAPI<I> _api;
  final _user = Observable<AuthenticatedUser<I>?>(null);
  final _pending = Observable<OAuth2?>(null);
  final _busy = Observable(false);
  int _generation = 0;
  Future<void>? _running;
  late final Future<void> initialized;

  UserAccountService(this._api) {
    initialized = _restore();
  }

  AuthenticationAPI<I> get api => _api;
  AuthenticatedUser<I>? get authenticatedUser => _user.value;
  bool get isLoggedIn => authenticatedUser != null;
  bool get isLoggedOut => !isLoggedIn;
  bool get busy => _busy.value;
  bool get pending => _pending.value != null;

  Future<void> _restore() async {
    final generation = _generation;
    final api = _api;
    try {
      final authentication = await api.restore();
      final user = authentication == null ? null : await api.user(authentication);
      if (generation == _generation) runInAction(() => _user.value = user);
    } on AuthenticationPendingException {
      if (generation == _generation) await api.logout();
    } catch (error) {
      debugPrint('Account restoration unavailable: ${error.runtimeType}');
    }
  }

  Future<void> refresh() => _restore();

  Future<void> login() {
    if (busy || isLoggedIn) return Future.value();
    runInAction(() => _busy.value = true);
    return _running = _login();
  }

  Future<void> _login() async {
    final generation = _generation;
    final api = _api;
    try {
      await initialized;
      if (generation != _generation || isLoggedIn) return;
      final fresh = !pending;
      final authentication = _pending.value ?? await api.login();
      if (generation != _generation) return;
      runInAction(() => _pending.value = authentication);
      if (fresh) {
        try {
          await openLogin(api, authentication);
        } catch (_) {
          if (generation == _generation) runInAction(() => _pending.value = null);
          rethrow;
        }
      }
      if (generation != _generation) return;
      final user = await api.user(authentication);
      if (generation != _generation) return;
      await api.save(authentication);
      if (generation != _generation) {
        // Session changes wait for this operation, so a cancelled write cannot
        // erase a newer credential.
        await api.logout();
        return;
      }
      runInAction(() {
        _user.value = user;
        _pending.value = null;
      });
    } on AuthenticationPendingException {
      // The browser may still be open. Resume or Check sign-in retries user().
    } on PlatformException catch (error) {
      if (generation == _generation && error.code != 'CANCELED') rethrow;
    } catch (_) {
      if (generation == _generation) rethrow;
    } finally {
      runInAction(() => _busy.value = false);
    }
  }

  void cancelLogin() {
    ++_generation;
    runInAction(() => _pending.value = null);
  }

  @protected
  Future<void> openLogin(AuthenticationAPI<I> api, OAuth2 authentication) async {}

  Future<void> clearLocalUser() async {
    cancelLogin();
    await initialized;
    try {
      await _running;
    } catch (_) {
      // A failed login must not prevent clearing the local account.
    }
    runInAction(() => _user.value = null);
  }

  @protected
  void updateApiConfiguration(AuthenticationAPI<I> api) {
    _api = api;
  }

  Future<void> logout() async {
    await clearLocalUser();
    try {
      await _api.logout();
    } catch (error) {
      debugPrint('Remote logout unavailable: ${error.runtimeType}');
    }
  }
}
