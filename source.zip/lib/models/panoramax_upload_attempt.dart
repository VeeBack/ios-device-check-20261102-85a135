import 'package:osm_api/osm_api.dart';

class PanoramaxUploadContext {
  final Uri instance;
  final String accountId;
  final OAuth2 authentication;
  const PanoramaxUploadContext({
    required this.instance,
    required this.accountId,
    required this.authentication,
  });
}

enum PhotoUploadStage { uploading, processing, saving }

/// Retained by the questionnaire worker, never by an API client.
class PanoramaxUploadAttempt {
  final PanoramaxUploadContext context;
  final Set<String> expectedIds;
  String? uploadSetId;
  PhotoUploadStage stage = PhotoUploadStage.uploading;
  PanoramaxUploadAttempt(this.context, Iterable<String> ids) : expectedIds = Set.unmodifiable(ids);
}
