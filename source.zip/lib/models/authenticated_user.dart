import 'package:osm_api/osm_api.dart';

/// OSM uses integer identities; Panoramax uses UUID strings.
class AuthenticatedUser<I> {
  final Auth authentication;
  final String name;
  final I id;
  final Uri? profileUrl;
  final String? profileImageUrl;
  final List<String> preferredLanguages;
  const AuthenticatedUser({
    required this.authentication,
    required this.name,
    required this.id,
    this.preferredLanguages = const [],
    this.profileUrl,
    this.profileImageUrl,
  });
}
