import 'package:flutter/foundation.dart';
import 'package:osm_api/osm_api.dart';
import 'package:url_launcher/url_launcher.dart';

/// OSM uses integer identities; Panoramax uses UUID strings.
class AuthenticatedUser<I> {
  final OAuth2 authentication;
  final String name;
  final I id;
  final Uri? profileUrl;
  final String? profileImageUrl;
  final List<String> preferredLanguages;
  const AuthenticatedUser({
    required this.authentication,
    required this.name,
    required this.id,
    this.preferredLanguages = const [],
    this.profileUrl,
    this.profileImageUrl,
  });

  Future<bool> openUserProfile() async {
    final url = profileUrl;
    if (url == null) return false;
    try {
      return await launchUrl(url, mode: LaunchMode.externalApplication);
    } catch (error) {
      debugPrint(error.toString());
      return false;
    }
  }
}
