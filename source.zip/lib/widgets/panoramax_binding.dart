import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';
import 'package:get_it/get_it.dart';
import 'package:url_launcher/url_launcher.dart';
import '/api/panoramax_connection.dart';
import '/l10n/app_localizations.g.dart';

/// Shared account binding for Services and the photo question.
class PanoramaxBinding extends StatelessWidget {
  final Widget Function(BuildContext, PanoramaxConnection) builder;
  const PanoramaxBinding({required this.builder, super.key});
  @override
  Widget build(BuildContext context) {
    final connection = GetIt.I<PanoramaxConnection>();
    return Observer(builder: (context) => builder(context, connection));
  }
}

class PanoramaxSignIn extends StatelessObserverWidget {
  final PanoramaxConnection connection;
  const PanoramaxSignIn(this.connection, {super.key});
  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(l.photoBrowserExplanation(connection.instance.url.toString())),
        const SizedBox(height: 8),
        if (connection.error != null)
          Text(switch (connection.error) {
            'browser' => l.photoBrowserError,
            'waiting' => l.photoSignInWaiting,
            _ => l.photoNetworkError,
          }),
        if (connection.pending || connection.busy) ...[
          OutlinedButton(onPressed: connection.check, child: Text(l.photoCheckSignIn)),
          TextButton(onPressed: connection.cancel, child: Text(l.cancel)),
        ] else
          FilledButton(onPressed: connection.signIn, child: Text(l.photoSignIn)),
      ],
    );
  }
}

class PanoramaxPublication extends StatelessWidget {
  final PanoramaxConnection connection;
  const PanoramaxPublication(this.connection, {super.key});
  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(l.photoPublication(connection.instance.url.toString())),
        Wrap(
          children: [
            if (connection.instance.license != null)
              TextButton(
                onPressed: () =>
                    launchUrl(connection.instance.license!, mode: LaunchMode.externalApplication),
                child: Text(l.photoLicense),
              ),
            if (connection.instance.terms != null)
              TextButton(
                onPressed: () =>
                    launchUrl(connection.instance.terms!, mode: LaunchMode.externalApplication),
                child: Text(l.photoTerms),
              ),
          ],
        ),
      ],
    );
  }
}
